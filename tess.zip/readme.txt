**STEPS**

1. Open config.py file as a py file or .txt and setup the configurations as menitioned in comments, But make sure to keep the file saved as .py only
2. Make sure theres sufficent amount for the total transfer ,if not the transaction will fail.
3. Save recieving addresses in the address.csv,
4. main.exe is the bot executable file
5. If facing any issue, please contact me on my twitter or reddit DMs ( My accounts are mentioned in github bio).


** IM NOT RESPONSIBLE FOR ANY LOSSES THAT MAY HAPPEN DURING REAL TRANSACTIONS, TEST ON TESTNET FIRST **

**BY SHAHEN B**